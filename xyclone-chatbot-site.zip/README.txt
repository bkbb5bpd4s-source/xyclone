XYCLONE — SITE + CHATBOT
========================

1. Ouvre index.html dans un navigateur pour tester le site.
2. Pour publier gratuitement : crée un compte GitHub, crée un dépôt public, ajoute index.html,
   puis active GitHub Pages dans Settings > Pages > Deploy from a branch > main > / (root).
3. Le chatbot inclus ici est un chatbot local à réponses prédéfinies : aucune clé API n'est nécessaire.
4. Pour transformer le bot en véritable IA, il faudra ajouter un backend sécurisé et une API d'IA.
